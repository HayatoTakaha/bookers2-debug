Rails.application.routes.draw do
  resources :books
end
