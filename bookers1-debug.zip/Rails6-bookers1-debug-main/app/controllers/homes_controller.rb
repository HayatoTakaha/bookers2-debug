class Controller < ApplicationController
  def top
  end
end
